document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const phoneNumberInput = document.getElementById('phoneNumber');
    const modeToggle = document.getElementById('modeToggle');
    const slideshow = document.getElementById('slideshow');
    const cities = document.querySelectorAll('.city');
    const contactForm = document.getElementById('contactForm');
    const messageInput = document.getElementById('message');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const phoneNumber = phoneNumberInput.value;
        alert(`Lambarkaaga waa la diiwaan geliyey: ${phoneNumber}`);
        // Here you would typically send this to a server or save it in a sheet
    });

    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const message = messageInput.value;
        alert(`Fariintaada waa la diray: ${message}`);
        // Here you would typically send this to a server or save it in a sheet
    });

    modeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
    });

    cities.forEach(city => {
        city.addEventListener('click', function() {
            alert(`Waxaad dooratay magaalada: ${city.dataset.city}`);
            // Here you would typically load data related to the selected city
        });
    });

    // Example slideshow images
    const images = [
        'https://via.placeholder.com/300x200?text=Property+1',
        'https://via.placeholder.com/300x200?text=Property+2',
        'https://via.placeholder.com/300x200?text=Property+3'
    ];

    images.forEach(src => {
        const img = document.createElement('img');
        img.src = src;
        slideshow.appendChild(img);
    });
});